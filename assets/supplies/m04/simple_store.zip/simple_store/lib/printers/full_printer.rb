class FullPrinter < Printer
end
